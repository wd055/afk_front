self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3518cd328ce4e3b75a667fecdf473a18",
    "url": "./index.html"
  },
  {
    "revision": "27edcf08f031f1dcff8a",
    "url": "./static/css/2.d34b324b.chunk.css"
  },
  {
    "revision": "27edcf08f031f1dcff8a",
    "url": "./static/js/2.71b62212.chunk.js"
  },
  {
    "revision": "e2f631dec120e98a2917416356266528",
    "url": "./static/js/2.71b62212.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b41baf1ef4b17368e7e5",
    "url": "./static/js/main.f571c85b.chunk.js"
  },
  {
    "revision": "bea8310ac82d8f18b365",
    "url": "./static/js/runtime-main.c9a1e25b.js"
  }
]);