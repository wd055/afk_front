self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "079b5783f8e7378daad3235b8c60a0cd",
    "url": "./index.html"
  },
  {
    "revision": "0e743f8ea22e4c5cc05e",
    "url": "./static/css/2.a6674286.chunk.css"
  },
  {
    "revision": "0e743f8ea22e4c5cc05e",
    "url": "./static/js/2.2db53e39.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.2db53e39.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0f63b3f78455431c2fbb",
    "url": "./static/js/main.a5aadba5.chunk.js"
  },
  {
    "revision": "93980e80c55fc80972a6",
    "url": "./static/js/runtime-main.bbe3d335.js"
  }
]);