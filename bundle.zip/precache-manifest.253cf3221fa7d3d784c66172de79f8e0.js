self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "754b70fef9b50287af9b330d525eba53",
    "url": "./index.html"
  },
  {
    "revision": "93888894c8b2920d3da7",
    "url": "./static/css/2.47f050ad.chunk.css"
  },
  {
    "revision": "93888894c8b2920d3da7",
    "url": "./static/js/2.5c7d4e93.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.5c7d4e93.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e92cca00fa8c24877037",
    "url": "./static/js/main.00233d84.chunk.js"
  },
  {
    "revision": "93980e80c55fc80972a6",
    "url": "./static/js/runtime-main.bbe3d335.js"
  }
]);