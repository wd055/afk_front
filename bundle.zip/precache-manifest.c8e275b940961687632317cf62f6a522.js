self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cb7d2c8abcbd0b0c3fd2c328b385fed6",
    "url": "./index.html"
  },
  {
    "revision": "1203d4f5328d4b46c926",
    "url": "./static/css/2.47f050ad.chunk.css"
  },
  {
    "revision": "1203d4f5328d4b46c926",
    "url": "./static/js/2.2b2599d0.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.2b2599d0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a569ced69943702de326",
    "url": "./static/js/main.f16c44ad.chunk.js"
  },
  {
    "revision": "93980e80c55fc80972a6",
    "url": "./static/js/runtime-main.bbe3d335.js"
  }
]);