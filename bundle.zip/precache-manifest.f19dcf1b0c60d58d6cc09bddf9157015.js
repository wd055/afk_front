self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6d22e8c9adb803e493af07119b5c615d",
    "url": "./index.html"
  },
  {
    "revision": "298158276ae7432cf43c",
    "url": "./static/css/2.9e627a5a.chunk.css"
  },
  {
    "revision": "273471f39d5ea2798865",
    "url": "./static/css/main.756d33d8.chunk.css"
  },
  {
    "revision": "298158276ae7432cf43c",
    "url": "./static/js/2.584dcd43.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.584dcd43.chunk.js.LICENSE.txt"
  },
  {
    "revision": "273471f39d5ea2798865",
    "url": "./static/js/main.03ced9b3.chunk.js"
  },
  {
    "revision": "93980e80c55fc80972a6",
    "url": "./static/js/runtime-main.bbe3d335.js"
  },
  {
    "revision": "7d5fedb97b50bf1012472ba0fbc5fc2d",
    "url": "./static/media/GZ.7d5fedb9.png"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik.4e1ec840.png"
  }
]);