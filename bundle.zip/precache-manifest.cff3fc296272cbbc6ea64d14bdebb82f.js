self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "23635ccd9abcea3d7243cefe4b023cbe",
    "url": "./index.html"
  },
  {
    "revision": "f5ed4629def4b96107e5",
    "url": "./static/css/2.1e562f28.chunk.css"
  },
  {
    "revision": "f5ed4629def4b96107e5",
    "url": "./static/js/2.c6f4f5c0.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.c6f4f5c0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4af36ea2a086e26cab70",
    "url": "./static/js/main.17d57fe7.chunk.js"
  },
  {
    "revision": "bea8310ac82d8f18b365",
    "url": "./static/js/runtime-main.c9a1e25b.js"
  }
]);