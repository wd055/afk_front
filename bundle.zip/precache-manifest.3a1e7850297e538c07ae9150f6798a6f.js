self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8adb717aebbf74a209258c32e52b4432",
    "url": "./index.html"
  },
  {
    "revision": "fcc71af42c496dd212b8",
    "url": "./static/css/2.47f050ad.chunk.css"
  },
  {
    "revision": "fcc71af42c496dd212b8",
    "url": "./static/js/2.889c7f7f.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.889c7f7f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "43a434ccc872378d1b0f",
    "url": "./static/js/main.76423f68.chunk.js"
  },
  {
    "revision": "93980e80c55fc80972a6",
    "url": "./static/js/runtime-main.bbe3d335.js"
  }
]);