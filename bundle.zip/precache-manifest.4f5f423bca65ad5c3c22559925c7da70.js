self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "adf379ed9444e6fff575923f4152b606",
    "url": "./index.html"
  },
  {
    "revision": "828a925f1954054f0cd7",
    "url": "./static/css/2.47f050ad.chunk.css"
  },
  {
    "revision": "828a925f1954054f0cd7",
    "url": "./static/js/2.9c38ee52.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.9c38ee52.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1bb2c5eebfadc5e47c1f",
    "url": "./static/js/main.4f52ec86.chunk.js"
  },
  {
    "revision": "93980e80c55fc80972a6",
    "url": "./static/js/runtime-main.bbe3d335.js"
  }
]);