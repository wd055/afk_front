self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "353ac59f067033b16c582aac6bf5066f",
    "url": "./index.html"
  },
  {
    "revision": "dc6d87c6769503976233",
    "url": "./static/css/2.47f050ad.chunk.css"
  },
  {
    "revision": "dc6d87c6769503976233",
    "url": "./static/js/2.b27b31bb.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.b27b31bb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3ba28c5f81fdfead6306",
    "url": "./static/js/main.2b84c6e9.chunk.js"
  },
  {
    "revision": "93980e80c55fc80972a6",
    "url": "./static/js/runtime-main.bbe3d335.js"
  }
]);